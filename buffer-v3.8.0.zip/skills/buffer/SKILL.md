---
name: buffer
description: Session buffer dispatcher. Routes to on (reconstruct) or off (handoff).
---

# Buffer Dispatcher

This skill routes to the correct operational skill. **Do not act on buffer data without loading the operational skill first.**

## Routing

If ARGUMENTS contains "on":
→ Invoke the `buffer:on` skill via the Skill tool. Follow its instructions completely.

If ARGUMENTS contains "off":
→ Invoke the `buffer:off` skill via the Skill tool. Follow its instructions completely.

If no argument or unrecognized argument:
→ **⚠ MANDATORY POPUP**: You MUST use `AskUserQuestion` to ask: "Start session (`/buffer:on`) or save handoff (`/buffer:off`)?" Do NOT guess. Do NOT default to either. Wait for the user's response.

## Rules

- **Do NOT search for buffer files.** The operational skill tells you how.
- **Do NOT read handoff.json.** The operational skill tells you when.
- **Do NOT use MEMORY.md to locate projects.** The operational skill has routing.
- If you already know where buffer files are, that knowledge is irrelevant until the operational skill loads. Invoke the skill first.
